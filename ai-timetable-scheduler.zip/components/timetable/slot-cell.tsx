"use client"

import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import type { TimetableSlot } from "@/lib/types"
import { cn } from "@/lib/utils"
import { Beaker, Cloud, Coffee, Sparkles } from "lucide-react"

interface SlotCellProps {
  slot?: TimetableSlot
  editable?: boolean
}

export function SlotCell({ slot, editable }: SlotCellProps) {
  if (!slot || !slot.subject) {
    return (
      <div
        className={cn(
          "h-20 p-2 flex items-center justify-center text-xs text-muted-foreground",
          editable && "hover:bg-muted/50 cursor-pointer transition-colors",
        )}
      >
        {editable && <span className="opacity-0 group-hover:opacity-100">+ Add</span>}
      </div>
    )
  }

  const getSlotColor = () => {
    if (slot.type === "lunch") return "bg-muted text-muted-foreground"
    if (slot.type === "lab") return "bg-chart-1/20 text-chart-1 border-l-4 border-chart-1"
    if (slot.type === "special") return "bg-chart-4/20 text-chart-4 border-l-4 border-chart-4"
    if (slot.type === "online") return "bg-chart-3/20 text-chart-3 border-2 border-dashed border-chart-3"
    return "bg-chart-2/20 text-chart-2 border-l-4 border-chart-2"
  }

  const getIcon = () => {
    if (slot.type === "lunch") return <Coffee className="h-3 w-3" />
    if (slot.type === "lab") return <Beaker className="h-3 w-3" />
    if (slot.type === "special") return <Sparkles className="h-3 w-3" />
    if (slot.type === "online") return <Cloud className="h-3 w-3" />
    return null
  }

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div
            className={cn(
              "h-20 p-2 flex flex-col gap-1 transition-all",
              getSlotColor(),
              editable && "hover:opacity-80 cursor-pointer",
            )}
          >
            <div className="flex items-center gap-1">
              {getIcon()}
              <span className="text-xs font-semibold truncate">{slot.subject}</span>
            </div>
            {slot.faculty && <span className="text-xs truncate opacity-90">{slot.faculty}</span>}
            {slot.room && <span className="text-xs truncate opacity-75">{slot.room}</span>}
            {slot.label && <span className="text-xs truncate font-medium">{slot.label}</span>}
          </div>
        </TooltipTrigger>
        <TooltipContent side="top" className="bg-popover border-border">
          <div className="space-y-1">
            <p className="font-semibold">{slot.subject || slot.label}</p>
            {slot.faculty && <p className="text-sm">Faculty: {slot.faculty}</p>}
            {slot.room && <p className="text-sm">Room: {slot.room}</p>}
            <p className="text-xs text-muted-foreground">
              {slot.day} • {slot.slot}
            </p>
            {slot.type && <p className="text-xs capitalize">Type: {slot.type}</p>}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}
