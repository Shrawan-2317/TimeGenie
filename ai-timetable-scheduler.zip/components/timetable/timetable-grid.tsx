"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { SlotCell } from "./slot-cell"
import { EditSlotModal } from "./edit-slot-modal"
import { CANONICAL_SLOTS, DAYS, type TimetableSlot } from "@/lib/types"
import { cn } from "@/lib/utils"

interface TimetableGridProps {
  classId: string
  slots: TimetableSlot[]
  editable?: boolean
  onSlotUpdate?: (slot: TimetableSlot) => void
  title?: string
}

export function TimetableGrid({ classId, slots, editable = false, onSlotUpdate, title }: TimetableGridProps) {
  const [selectedSlot, setSelectedSlot] = useState<TimetableSlot | null>(null)
  const [editModalOpen, setEditModalOpen] = useState(false)

  const getSlotData = (day: string, timeSlot: string): TimetableSlot | undefined => {
    return slots.find((s) => s.day === day && s.slot === timeSlot)
  }

  const handleSlotClick = (day: string, timeSlot: string) => {
    if (!editable) return

    const existingSlot = getSlotData(day, timeSlot)
    setSelectedSlot(
      existingSlot || {
        day,
        slot: timeSlot,
      },
    )
    setEditModalOpen(true)
  }

  const handleSlotSave = (updatedSlot: TimetableSlot) => {
    if (onSlotUpdate) {
      onSlotUpdate(updatedSlot)
    }
    setEditModalOpen(false)
    setSelectedSlot(null)
  }

  return (
    <div className="space-y-4">
      {title && <h3 className="text-lg font-semibold">{title}</h3>}

      <Card className="border-border bg-card overflow-hidden">
        <div className="overflow-x-auto">
          <div className="min-w-[800px]">
            {/* Header Row */}
            <div className="grid grid-cols-[100px_repeat(6,1fr)] border-b border-border bg-muted/50">
              <div className="p-3 font-medium text-sm">Time</div>
              {DAYS.map((day) => (
                <div key={day} className="p-3 font-medium text-sm text-center border-l border-border">
                  {day}
                </div>
              ))}
            </div>

            {/* Time Slots */}
            {CANONICAL_SLOTS.map((timeSlot, index) => (
              <div
                key={timeSlot}
                className={cn(
                  "grid grid-cols-[100px_repeat(6,1fr)] border-b border-border",
                  index % 2 === 0 ? "bg-card" : "bg-muted/20",
                )}
              >
                <div className="p-3 text-sm font-mono text-muted-foreground flex items-center">{timeSlot}</div>
                {DAYS.map((day) => {
                  const slotData = getSlotData(day, timeSlot)
                  return (
                    <div
                      key={`${day}-${timeSlot}`}
                      className="border-l border-border"
                      onClick={() => handleSlotClick(day, timeSlot)}
                    >
                      <SlotCell slot={slotData} editable={editable} />
                    </div>
                  )
                })}
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* Legend */}
      <div className="flex flex-wrap gap-4 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-chart-2" />
          <span className="text-muted-foreground">Theory</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-chart-1" />
          <span className="text-muted-foreground">Lab</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-chart-4" />
          <span className="text-muted-foreground">Special</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded bg-muted" />
          <span className="text-muted-foreground">Lunch</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded border-2 border-dashed border-chart-3" />
          <span className="text-muted-foreground">Online</span>
        </div>
      </div>

      {/* Edit Modal */}
      {selectedSlot && (
        <EditSlotModal
          open={editModalOpen}
          onOpenChange={setEditModalOpen}
          slot={selectedSlot}
          onSave={handleSlotSave}
        />
      )}
    </div>
  )
}
