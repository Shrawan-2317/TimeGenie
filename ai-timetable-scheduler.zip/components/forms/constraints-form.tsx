"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import type { InputData } from "@/lib/types"

interface ConstraintsFormProps {
  data: InputData
  setData: (data: InputData) => void
}

export function ConstraintsForm({ data, setData }: ConstraintsFormProps) {
  const updateConstraints = (field: string, value: any) => {
    setData({
      ...data,
      constraints: {
        ...data.constraints,
        [field]: value,
      },
    })
  }

  return (
    <div className="space-y-4">
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle>Constraints</CardTitle>
          <CardDescription>Set scheduling constraints and rules</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="max-hours">Max Hours per Day</Label>
            <Input
              id="max-hours"
              type="number"
              value={data.constraints.max_hours_per_day}
              onChange={(e) => updateConstraints("max_hours_per_day", Number.parseInt(e.target.value) || 7)}
              className="bg-background border-border"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="max-consecutive">Max Consecutive Theory Classes</Label>
            <Input
              id="max-consecutive"
              type="number"
              value={data.constraints.max_consecutive_theory}
              onChange={(e) => updateConstraints("max_consecutive_theory", Number.parseInt(e.target.value) || 3)}
              className="bg-background border-border"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="lunch-break">Lunch Break Time</Label>
            <Input
              id="lunch-break"
              placeholder="e.g., 12:40-01:40"
              value={data.constraints.lunch_break}
              onChange={(e) => updateConstraints("lunch_break", e.target.value)}
              className="bg-background border-border"
            />
          </div>

          <div className="pt-4 border-t border-border">
            <p className="text-sm text-muted-foreground">
              Additional constraints like online days and special slots can be configured after saving the basic data.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
