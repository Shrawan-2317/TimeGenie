import { NextResponse } from "next/server"

// Mock timetables database
let timetables = [
  {
    id: "tt-001",
    name: "CSE 3rd Year - Semester 5",
    classId: "CSE-3A",
    semester: 5,
    academicYear: "2024-25",
    status: "published",
    version: 3,
    createdBy: "admin-001",
    createdAt: "2024-01-15T10:00:00Z",
    publishedAt: "2024-01-20T14:30:00Z",
    slots: [],
  },
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const status = searchParams.get("status")
  const classId = searchParams.get("classId")

  let filtered = timetables

  if (status) {
    filtered = filtered.filter((tt) => tt.status === status)
  }

  if (classId) {
    filtered = filtered.filter((tt) => tt.classId === classId)
  }

  return NextResponse.json(filtered)
}

export async function POST(request: Request) {
  const body = await request.json()

  const newTimetable = {
    id: `tt-${Date.now()}`,
    ...body,
    version: 1,
    createdAt: new Date().toISOString(),
    status: "draft",
  }

  timetables.push(newTimetable)

  return NextResponse.json(newTimetable, { status: 201 })
}

export async function PUT(request: Request) {
  const body = await request.json()
  const { id, ...updates } = body

  const index = timetables.findIndex((tt) => tt.id === id)

  if (index === -1) {
    return NextResponse.json({ error: "Timetable not found" }, { status: 404 })
  }

  timetables[index] = {
    ...timetables[index],
    ...updates,
    version: timetables[index].version + 1,
  }

  return NextResponse.json(timetables[index])
}

export async function DELETE(request: Request) {
  const { searchParams } = new URL(request.url)
  const id = searchParams.get("id")

  if (!id) {
    return NextResponse.json({ error: "ID required" }, { status: 400 })
  }

  timetables = timetables.filter((tt) => tt.id !== id)

  return NextResponse.json({ success: true })
}
