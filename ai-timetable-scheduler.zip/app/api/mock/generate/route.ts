import { NextResponse } from "next/server"

// Simulates AI timetable generation
export async function POST(request: Request) {
  const body = await request.json()
  const { classId, semester, preferences } = body

  // Simulate processing time
  await new Promise((resolve) => setTimeout(resolve, 2000))

  // Generate mock timetable slots
  const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
  const timeSlots = [
    { start: "09:00", end: "10:00" },
    { start: "10:00", end: "11:00" },
    { start: "11:15", end: "12:15" },
    { start: "12:15", end: "13:15" },
    { start: "14:00", end: "15:00" },
    { start: "15:00", end: "16:00" },
    { start: "16:15", end: "17:15" },
  ]

  const subjects = [
    { code: "CS501", name: "Machine Learning", type: "theory", faculty: "Dr. Smith" },
    { code: "CS502", name: "Database Systems", type: "theory", faculty: "Dr. Johnson" },
    { code: "CS503", name: "Computer Networks", type: "theory", faculty: "Dr. Williams" },
    { code: "CS504", name: "ML Lab", type: "lab", faculty: "Dr. Smith" },
    { code: "CS505", name: "DBMS Lab", type: "lab", faculty: "Dr. Johnson" },
  ]

  const slots = []

  for (let dayIndex = 0; dayIndex < days.length; dayIndex++) {
    for (let slotIndex = 0; slotIndex < timeSlots.length; slotIndex++) {
      // Add lunch break
      if (slotIndex === 3) {
        slots.push({
          id: `slot-${dayIndex}-${slotIndex}`,
          day: days[dayIndex],
          startTime: timeSlots[slotIndex].start,
          endTime: timeSlots[slotIndex].end,
          type: "lunch",
          subjectCode: "LUNCH",
          subjectName: "Lunch Break",
          facultyId: null,
          facultyName: null,
          roomNumber: null,
        })
        continue
      }

      // Randomly assign subjects
      const subject = subjects[Math.floor(Math.random() * subjects.length)]

      slots.push({
        id: `slot-${dayIndex}-${slotIndex}`,
        day: days[dayIndex],
        startTime: timeSlots[slotIndex].start,
        endTime: timeSlots[slotIndex].end,
        type: subject.type,
        subjectCode: subject.code,
        subjectName: subject.name,
        facultyId: `fac-${Math.floor(Math.random() * 100)}`,
        facultyName: subject.faculty,
        roomNumber:
          subject.type === "lab"
            ? `Lab-${Math.floor(Math.random() * 5) + 1}`
            : `Room-${Math.floor(Math.random() * 20) + 101}`,
      })
    }
  }

  const timetable = {
    id: `tt-${Date.now()}`,
    name: `${classId} - Semester ${semester}`,
    classId,
    semester,
    status: "draft",
    version: 1,
    createdAt: new Date().toISOString(),
    slots,
    conflicts: [],
    aiScore: Math.floor(Math.random() * 20) + 80, // 80-100
  }

  return NextResponse.json(timetable)
}
