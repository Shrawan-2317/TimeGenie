import { NextResponse } from "next/server"

// Detect conflicts in timetable
export async function POST(request: Request) {
  const body = await request.json()
  const { slots } = body

  const conflicts = []

  // Check for faculty conflicts (same faculty, same time, different classes)
  const facultySlots = new Map()

  for (const slot of slots) {
    if (!slot.facultyId) continue

    const key = `${slot.day}-${slot.startTime}-${slot.facultyId}`

    if (facultySlots.has(key)) {
      conflicts.push({
        type: "faculty",
        severity: "high",
        message: `${slot.facultyName} has overlapping classes on ${slot.day} at ${slot.startTime}`,
        slots: [facultySlots.get(key), slot.id],
      })
    } else {
      facultySlots.set(key, slot.id)
    }
  }

  // Check for room conflicts
  const roomSlots = new Map()

  for (const slot of slots) {
    if (!slot.roomNumber) continue

    const key = `${slot.day}-${slot.startTime}-${slot.roomNumber}`

    if (roomSlots.has(key)) {
      conflicts.push({
        type: "room",
        severity: "high",
        message: `${slot.roomNumber} is double-booked on ${slot.day} at ${slot.startTime}`,
        slots: [roomSlots.get(key), slot.id],
      })
    } else {
      roomSlots.set(key, slot.id)
    }
  }

  // Check for workload (faculty teaching too many consecutive hours)
  const facultyDaySlots = new Map()

  for (const slot of slots) {
    if (!slot.facultyId || slot.type === "lunch") continue

    const key = `${slot.facultyId}-${slot.day}`

    if (!facultyDaySlots.has(key)) {
      facultyDaySlots.set(key, [])
    }

    facultyDaySlots.get(key).push(slot)
  }

  for (const [key, daySlots] of facultyDaySlots) {
    if (daySlots.length > 6) {
      conflicts.push({
        type: "workload",
        severity: "medium",
        message: `${daySlots[0].facultyName} has ${daySlots.length} classes on ${daySlots[0].day}`,
        slots: daySlots.map((s) => s.id),
      })
    }
  }

  return NextResponse.json({ conflicts, count: conflicts.length })
}
