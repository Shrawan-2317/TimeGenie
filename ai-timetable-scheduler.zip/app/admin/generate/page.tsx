"use client"

import { useState } from "react"
import { AdminLayout } from "@/components/layouts/admin-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { TimetableGrid } from "@/components/timetable/timetable-grid"
import { useAppStore } from "@/lib/store"
import { generateSampleTimetable } from "@/lib/timetable-utils"
import { Sparkles, RefreshCw, Save } from "lucide-react"
import type { TimetableSlot } from "@/lib/types"

export default function GeneratePage() {
  const { inputData, draftVersion, setDraftVersion } = useAppStore()
  const [selectedClass, setSelectedClass] = useState<string>("TY1")
  const [isGenerating, setIsGenerating] = useState(false)
  const [timetableSlots, setTimetableSlots] = useState<TimetableSlot[]>([])

  const handleGenerate = async () => {
    setIsGenerating(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const generatedSlots = generateSampleTimetable(selectedClass)
    setTimetableSlots(generatedSlots)

    setDraftVersion({
      version: `v1.0-draft-${Date.now()}`,
      status: "draft",
      created_at: new Date().toISOString(),
      class_timelines: {
        [selectedClass]: generatedSlots,
      },
      metrics: {
        conflicts: 0,
        soft_score: 87,
      },
    })

    setIsGenerating(false)
  }

  const handleSlotUpdate = (updatedSlot: TimetableSlot) => {
    const newSlots = timetableSlots.filter((s) => !(s.day === updatedSlot.day && s.slot === updatedSlot.slot))

    if (updatedSlot.subject || updatedSlot.label) {
      newSlots.push(updatedSlot)
    }

    setTimetableSlots(newSlots)

    if (draftVersion) {
      setDraftVersion({
        ...draftVersion,
        class_timelines: {
          ...draftVersion.class_timelines,
          [selectedClass]: newSlots,
        },
      })
    }
  }

  const handleSaveDraft = () => {
    // In a real app, this would save to backend
    alert("Draft saved successfully!")
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Generate Timetable</h2>
          <p className="text-muted-foreground">Create and edit AI-generated timetables</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-4">
          <Card className="border-border bg-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Conflicts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-chart-1">{draftVersion?.metrics?.conflicts ?? 0}</div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Soft Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-chart-2">{draftVersion?.metrics?.soft_score ?? 0}</div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm font-medium capitalize">{draftVersion?.status ?? "Not Generated"}</div>
            </CardContent>
          </Card>

          <Card className="border-border bg-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Version</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm font-mono">{draftVersion?.version ?? "N/A"}</div>
            </CardContent>
          </Card>
        </div>

        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle>Generation Controls</CardTitle>
            <CardDescription>Select a class and generate an optimized timetable</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4 items-end">
              <div className="flex-1 space-y-2">
                <label className="text-sm font-medium">Select Class</label>
                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {inputData &&
                      Object.keys(inputData.classes).map((classId) => (
                        <SelectItem key={classId} value={classId}>
                          {inputData.classes[classId].name}
                        </SelectItem>
                      ))}
                    {!inputData && (
                      <>
                        <SelectItem value="TY1">Third Year Section 1</SelectItem>
                        <SelectItem value="TY2">Third Year Section 2</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
              </div>

              <Button
                onClick={handleGenerate}
                disabled={isGenerating}
                className="bg-primary text-primary-foreground gap-2"
              >
                {isGenerating ? (
                  <>
                    <RefreshCw className="h-4 w-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    Generate
                  </>
                )}
              </Button>

              {timetableSlots.length > 0 && (
                <Button onClick={handleSaveDraft} variant="outline" className="gap-2 bg-transparent">
                  <Save className="h-4 w-4" />
                  Save Draft
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {timetableSlots.length > 0 && (
          <TimetableGrid
            classId={selectedClass}
            slots={timetableSlots}
            editable={true}
            onSlotUpdate={handleSlotUpdate}
            title={`Timetable for ${selectedClass}`}
          />
        )}

        {timetableSlots.length === 0 && (
          <Card className="border-border bg-card">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Sparkles className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Timetable Generated</h3>
              <p className="text-sm text-muted-foreground text-center max-w-md">
                Select a class and click Generate to create an AI-optimized timetable. You can edit individual slots
                after generation.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </AdminLayout>
  )
}
