"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAppStore } from "@/lib/store"
import type { UserRole } from "@/lib/types"
import { Calendar, Users, GraduationCap } from "lucide-react"

export default function HomePage() {
  const router = useRouter()
  const setUser = useAppStore((state) => state.setUser)
  const [email, setEmail] = useState("")
  const [role, setRole] = useState<UserRole>("student")

  const handleSignIn = () => {
    // Mock authentication - create user based on email and role
    const user = {
      id: Math.random().toString(36).substr(2, 9),
      email,
      name: email.split("@")[0],
      role,
      facultyId: role === "teacher" ? "Dr. A" : undefined,
      classId: role === "student" ? "TY1" : undefined,
    }

    setUser(user)

    // Redirect based on role
    if (role === "admin") {
      router.push("/admin/dashboard")
    } else if (role === "teacher") {
      router.push("/teacher/home")
    } else {
      router.push("/student/home")
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-6xl mb-12 text-center">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="p-3 rounded-xl gradient-primary shadow-lg">
            <Calendar className="h-12 w-12 text-white" />
          </div>
          <h1 className="text-5xl font-bold tracking-tight gradient-text">AI Timetable Scheduler</h1>
        </div>
        <p className="text-xl text-gray-600">Intelligent scheduling system for educational institutions</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-6xl mb-12">
        <Card className="gradient-border overflow-hidden hover:shadow-lg transition-shadow">
          <CardHeader className="bg-gradient-to-br from-pink-50 to-white">
            <div className="p-2 rounded-lg gradient-primary w-fit mb-2">
              <Users className="h-8 w-8 text-white" />
            </div>
            <CardTitle className="gradient-text">Admin Portal</CardTitle>
            <CardDescription>Create and manage timetables, publish schedules, and handle approvals</CardDescription>
          </CardHeader>
        </Card>

        <Card className="gradient-border overflow-hidden hover:shadow-lg transition-shadow">
          <CardHeader className="bg-gradient-to-br from-orange-50 to-white">
            <div className="p-2 rounded-lg gradient-secondary w-fit mb-2">
              <GraduationCap className="h-8 w-8 text-white" />
            </div>
            <CardTitle className="gradient-text">Teacher Portal</CardTitle>
            <CardDescription>View your schedule, submit change requests, and manage class timetables</CardDescription>
          </CardHeader>
        </Card>

        <Card className="gradient-border overflow-hidden hover:shadow-lg transition-shadow">
          <CardHeader className="bg-gradient-to-br from-yellow-50 to-white">
            <div className="p-2 rounded-lg gradient-accent w-fit mb-2">
              <Calendar className="h-8 w-8 text-orange-600" />
            </div>
            <CardTitle className="gradient-text">Student Portal</CardTitle>
            <CardDescription>Access your class timetable and stay updated with schedule changes</CardDescription>
          </CardHeader>
        </Card>
      </div>

      <Card className="w-full max-w-md gradient-border overflow-hidden shadow-xl">
        <CardHeader className="bg-gradient-to-br from-pink-50 via-orange-50 to-yellow-50">
          <CardTitle className="gradient-text">Sign In</CardTitle>
          <CardDescription>Select your role and enter your email to continue</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 bg-white pt-6">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="your.email@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-white border-pink-200 focus:border-pink-400 focus:ring-pink-400"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="role">Role</Label>
            <Select value={role} onValueChange={(value) => setRole(value as UserRole)}>
              <SelectTrigger id="role" className="bg-white border-pink-200 focus:border-pink-400 focus:ring-pink-400">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="admin">Administrator</SelectItem>
                <SelectItem value="teacher">Teacher</SelectItem>
                <SelectItem value="student">Student</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button
            onClick={handleSignIn}
            className="w-full gradient-primary text-white border-0 hover:opacity-90 transition-opacity"
            disabled={!email}
          >
            Sign In
          </Button>

          <div className="pt-4 border-t border-pink-200">
            <p className="text-sm text-muted-foreground mb-2">Demo accounts:</p>
            <div className="space-y-1 text-xs font-mono text-muted-foreground">
              <p>admin@example.com (Admin)</p>
              <p>teacherA@example.com (Teacher)</p>
              <p>student1@example.com (Student)</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
