// Core data models for the timetable system

export type UserRole = "admin" | "teacher" | "student"

export interface User {
  id: string
  email: string
  name: string
  role: UserRole
  facultyId?: string // For teachers
  classId?: string // For students
}

export interface Class {
  id: string
  name: string
  subjects: string[]
  class_teacher: string
  strength: number
}

export interface Subject {
  code: string
  name: string
  type: "theory" | "lab"
  hours_per_week: number
  faculties: string[]
  requires_lab?: boolean
  duration?: number // For labs (in slots)
}

export interface Faculty {
  id: string
  name: string
  subjects: string[]
  max_hours_per_day: number
  unavailable_slots: string[]
}

export interface Room {
  id: string
  type: "classroom" | "lab"
  capacity: number
  facilities: string[]
}

export interface Constraints {
  online_days: Record<string, string[]>
  special_slots: Record<string, Record<string, string>>
  max_hours_per_day: number
  max_consecutive_theory: number
  lunch_break: string
}

export interface TimetableSlot {
  day: string
  slot: string
  subject?: string
  faculty?: string
  room?: string
  type?: "theory" | "lab" | "special" | "lunch" | "online"
  label?: string
}

export interface ClassTimetable {
  classId: string
  slots: TimetableSlot[]
}

export interface TimetableVersion {
  id: string
  version: string
  created_at: string
  created_by: string
  status: "draft" | "pending" | "approved" | "active" | "archived"
  changes: string
  slots: TimetableSlot[]
}

export interface ChangeRequest {
  id: string
  timetableVersion: string
  facultyId: string
  facultyName: string
  status: "pending" | "approved" | "rejected"
  comment: string
  created_at: string
}

export interface Notification {
  id: string
  type: "info" | "success" | "warning" | "error"
  title: string
  message: string
  timestamp: string
  read: boolean
  actionUrl?: string
}

export interface InputData {
  classes: Record<string, Class>
  subjects: Record<string, Subject>
  faculties: Record<string, Faculty>
  rooms: Record<string, Room>
  constraints: Constraints
}

// Canonical time slots
export const CANONICAL_SLOTS = [
  "08:45-09:40",
  "09:40-10:35",
  "10:50-11:45",
  "11:45-12:40",
  "12:40-13:40",
  "13:40-14:35",
  "14:35-15:30",
  "15:40-16:30",
]

export const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
